
package javaapplication3;

import java.util.Scanner;

public class StudentManagementApp {

    public static void main(String[] args) {
        System.out.println("STUDENT MANAGEMENT APPLICATION");
        System.out.println("");
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter (1) to launch menu or any other key to exit: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        if (choice == 1) {
            displayMenu(scanner);
        } else {
            System.out.println("Exiting application. Goodbye!");
        }
    }

    private static void displayMenu(Scanner scanner) {
        int choice;
        do {
            System.out.println("STUDENT MANAGEMENT MENU");
            System.out.println("1. Add Student");
            System.out.println("2. View Students");
            System.out.println("3. Edit Student");
            System.out.println("4. Delete Student");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.println("Add Student");
                    break;
                case 2:
                    System.out.println("View Students");
                    break;
                case 3:
                    System.out.println("Edit Student");
                    break;
                case 4:
                    System.out.println("Delete Student");
                    break;
                case 5:
                    System.out.println("Exiting application. Goodbye!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
}
